import os

contents = os.listdir(os.getcwd())

print(contents)
